const CACHE_NAME = 'fyzen-v1';
const assets = [
  '/',
  '/index.html',
  '/assets/css/styles.css',
  '/assets/js/main.js'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(assets);
    })
  );
});

self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(response => {
      return response || fetch(e.request);
    })
  );
});
